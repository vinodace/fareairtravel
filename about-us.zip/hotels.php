<!DOCTYPE html>
<html>

<head>
  <title>Hotels</title>

<?php include("header.php"); ?>

<div class="position-relative">
  <script charset="utf-8" type="text/javascript" src="https://hotels.fareairtravel.com/iframe.js"></script>
  <div class="wlwmark-hide"></div>
</div>  

<section class="container pb-5">
  <div class="row">
    <div class="col-md-12">
      <div class="position-relative d-flex justify-content-center py-5">
        <script async src="https://tpwdg.com/content?currency=usd&trs=453183&shmarker=67899&type=compact&host=hotels.fareairtravel.com%2Fhotels&locale=en&limit=10&powered_by=true&nobooking=&primary=%230b156a&special=%23e0e0e0&promo_id=4026&campaign_id=101" charset="utf-8"></script>
        <div class="hide-watermark"></div>
      </div>
    </div>
    <!-- <div class="col-md-12">
      <div class="position-relative">
        
        <div class="hide-watermark"></div>
      </div>
    </div> -->
  </div>
</section>
<?php include("footer.php"); ?>

 