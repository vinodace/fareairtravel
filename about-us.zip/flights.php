<!DOCTYPE html>
<html>

<head>
  <title>Flights</title>

<?php include("header.php"); ?>


<div class="position-relative">
  <script charset="utf-8" type="text/javascript" src="https://flights.fareairtravel.com/iframe.js"></script>
  <div class="wlwmark-hide"></div>
</div>

<!-- <section class="container pt-5">
  <div class="row">
    <div class="col-md-12">
      <h2 class="wrap-hding text-center pb-3">Search cheap flights by destination</h2>
    </div>
    <div class="col-md-12">
      <div class="position-relative">
        
        <div class="hide-watermark"></div>
      </div>
    </div>
  </div>
</section> -->

<?php include("footer.php"); ?>

 